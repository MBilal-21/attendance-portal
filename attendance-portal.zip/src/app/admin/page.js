"use client";

import { useEffect, useState } from "react";

export default function AdminDashboard() {
  const [stats, setStats] = useState({
    students: 0,
    teachers: 0,
    classes: 0,
    subjects: 0,
  });

  useEffect(() => {
    async function fetchStats() {
      try {
        const res = await fetch("/api/admin/stats");
        const data = await res.json();
        setStats(data);
      } catch (err) {
        console.error("Failed to fetch stats:", err);
      }
    }

    fetchStats();
  }, []);

  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Admin Dashboard</h1>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-blue-500 text-white p-6 rounded-lg shadow-lg">
          <h2 className="text-xl font-semibold mb-2">Students</h2>
          <p className="text-3xl font-bold">{stats.students}</p>
        </div>

        <div className="bg-green-500 text-white p-6 rounded-lg shadow-lg">
          <h2 className="text-xl font-semibold mb-2">Teachers</h2>
          <p className="text-3xl font-bold">{stats.teachers}</p>
        </div>

        <div className="bg-yellow-500 text-white p-6 rounded-lg shadow-lg">
          <h2 className="text-xl font-semibold mb-2">Classes</h2>
          <p className="text-3xl font-bold">{stats.classes}</p>
        </div>

        <div className="bg-red-500 text-white p-6 rounded-lg shadow-lg">
          <h2 className="text-xl font-semibold mb-2">Subjects</h2>
          <p className="text-3xl font-bold">{stats.subjects}</p>
        </div>
      </div>

      <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        <a
          href="/admin/students"
          className="bg-gray-800 text-white p-6 rounded-lg shadow-lg hover:bg-gray-700 text-center"
        >
          Manage Students
        </a>
        <a
          href="/admin/teachers"
          className="bg-gray-800 text-white p-6 rounded-lg shadow-lg hover:bg-gray-700 text-center"
        >
          Manage Teachers
        </a>
        <a
          href="/admin/programs"
          className="bg-gray-800 text-white p-6 rounded-lg shadow-lg hover:bg-gray-700 text-center"
        >
          Manage Programs
        </a>
        <a
          href="/admin/classes"
          className="bg-gray-800 text-white p-6 rounded-lg shadow-lg hover:bg-gray-700 text-center"
        >
          Manage Classes
        </a>
        <a
          href="/admin/subjects"
          className="bg-gray-800 text-white p-6 rounded-lg shadow-lg hover:bg-gray-700 text-center"
        >
          Manage Subjects
        </a>
        <a
          href="/admin/assign"
          className="bg-gray-800 text-white p-6 rounded-lg shadow-lg hover:bg-gray-700 text-center"
        >
          Assign Teacher
        </a>
        <a
          href="/admin/attendance"
          className="bg-gray-800 text-white p-6 rounded-lg shadow-lg hover:bg-gray-700 text-center"
        >
          Attendance
        </a>
      </div>
    </div>
  );
}
