export default function AdminLayout({ children }) {
  return (
    <div className="flex">
      {/* Sidebar */}
      <aside className="w-64 h-screen bg-gray-900 text-white p-4 space-y-4">
        <h2 className="text-xl font-bold mb-4">Admin Panel</h2>

        <nav className="flex flex-col space-y-2">
          <a href="/admin" className="hover:bg-gray-700 p-2 rounded">Dashboard</a>
          <a href="/admin/students" className="hover:bg-gray-700 p-2 rounded">Students</a>
          <a href="/admin/teachers" className="hover:bg-gray-700 p-2 rounded">Teachers</a>
          <a href="/admin/programs" className="hover:bg-gray-700 p-2 rounded">Programs</a>
          <a href="/admin/classes" className="hover:bg-gray-700 p-2 rounded">Classes</a>
          <a href="/admin/subjects" className="hover:bg-gray-700 p-2 rounded">Subjects</a>
          <a href="/admin/assign" className="hover:bg-gray-700 p-2 rounded">Assign Teacher</a>
          <a href="/admin/attendance" className="hover:bg-gray-700 p-2 rounded">Attendance</a>
        </nav>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-6">{children}</main>
    </div>
  );
}
